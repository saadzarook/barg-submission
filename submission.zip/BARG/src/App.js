
import './App.css';
import React, { Component } from 'react';
import Main from './components/MainComponent';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'react-redux';
import { ConfigureStore } from './redux/configureStore';

const store = ConfigureStore();

class App extends Component {

  
  render() {
    return (
      <Provider store={store}>
      <BrowserRouter>
      <div>
        <Main/>
      </div>
      </BrowserRouter>
      </Provider>
    );
  }
}

//Lifecycle methods
//Called when an instance of a component is being createc and inserted into the DOM
//contructor() , getDerivedStateFromProps(), render(), componentDidMount()

export default App;
