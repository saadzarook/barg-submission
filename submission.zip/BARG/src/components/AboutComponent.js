import React from 'react';
import { Breadcrumb, BreadcrumbItem, Card, CardBody, CardHeader, Media } from 'reactstrap';
import { Link } from 'react-router-dom';

function RenderLeader({leader}) {
    //console.log(leader.image)
    return (
        <Media key={leader.id}>
            <Media>
        <Media object src={leader.image} alt={leader.name} />
      </Media>
      <Media body className="ml-5 mb-5">
        <Media heading>{leader.name} </Media>
        <p>{leader.designation}</p>
        <p>{leader.description}</p>
      </Media>
    </Media>
      );
}



function About(props) {

    const leaders = props.leaders.map((leader) => {
        //console.log(leader.name)
        return (
            <RenderLeader leader={leader}/>
        );
    });

    return(
        <div className="container">
            <div className="row">
                <Breadcrumb>
                    <BreadcrumbItem><Link to="/home">Home</Link></BreadcrumbItem>
                    <BreadcrumbItem active>About Us</BreadcrumbItem>
                </Breadcrumb>
                <div className="col-12">
                    <h3>About Us</h3>
                    <hr />
                </div>                
            </div>
            <div className="row row-content">
                <div className="col-12 col-md-6">
                    <h2>Our Vision</h2>
                    <p>Started in 2021, BARG became the most demanding analysis generator for restaurants in Sri Lanka. Our platform was highly welcomed by investors for providing the best user experience with real-time data. BARG looks forward to encourage young investors to take the right decisions with the analysis given by our platform.</p>
                    <p>Feel free to play around with our platform. You may find this as the go-to-place even to plan your next dinner out.</p>
                </div>
                <div className="col-12 col-md-5">
                    <Card>
                        <CardHeader className="bg-primary text-white">Facts At a Glance</CardHeader>
                        <CardBody>
                            <dl className="row p-1">
                                <dt className="col-6">Active Users</dt>
                                <dd className="col-6">313</dd>
                                <dt className="col-6">Cumulative Visitors</dt>
                                <dd className="col-6">231,233</dd>
                                <dt className="col-6">Reports Generated</dt>
                                <dd className="col-6">45,677</dd>
                                <dt className="col-6">Current Ads</dt>
                                <dd className="col-6">14</dd>
                            </dl>
                        </CardBody>
                    </Card>
                </div>
                <div className="col-12">
                    <Card>
                        <CardBody className="bg-faded">
                            <blockquote className="blockquote">
                                <p className="mb-0">Pizza Mania was established and is moving forward successfully with the analysis we get from BARG.</p>
                                <footer className="blockquote-footer">D Fernando,
                                <cite title="Source Title">Owner of Pizza Mania,
                                    Dehiwela, Colombo</cite>
                                </footer>
                            </blockquote>
                        </CardBody>
                    </Card>
                </div>
                <div className="col-12">
                    <Card>
                        <CardBody className="bg-faded">
                            <blockquote className="blockquote">
                                <p className="mb-0">This platform is the best if you want to plan your startup restaurant and it's totally free!</p>
                                <footer className="blockquote-footer">Piumi Perera,
                                <cite title="Source Title">Director, Colombo Rent&Lease (Pvt) Ltd,
                                    Nugegoda, Colombo</cite>
                                </footer>
                            </blockquote>
                        </CardBody>
                    </Card>
                </div>
            </div>
            <div className="row row-content">
                <div className="col-12">
                    <h2>The Team</h2>
                </div>
                <div className="col-12">
                    <Media list>
                        {leaders}
                    </Media>
                </div>
            </div>
        </div>
    );
}

export default About;    