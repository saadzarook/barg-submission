import React, { Component } from 'react';
import { Card, CardImg, CardText, CardBody, CardTitle } from 'reactstrap';
import { COMMENTS } from '../shared/comments'

class RestaurantDetail extends Component{

    constructor(props){
        super(props)

        this.state = {
            comments : COMMENTS
        };
        
    }

renderComments(selectedRestaurant){
    if(selectedRestaurant != null){
        return(
            <div>
                <h4>Comments</h4>
                {this.state.comments.map((comment) => {
                    if(comment.restaurant_id === selectedRestaurant.id){
                        return(
                            <div>
                                {comment.comments.map((customer) => {
                                  return(
                                      <ul class = "list-unstyled" key={customer.author}>
                                          <p>{customer.text}</p>
                                          <p>-- {customer.author}, {customer.date}</p>
                                      </ul>
                                  );  
                                })}
                            </div>
                        );
                    }
                    else{
                        return(
                            <div></div>
                        );
                    }
                }
                )}
            </div>
           );
    }
    else{
        return(
            <div></div>
        );
    }
    
}

render(){
    if(this.props.restaurant != null){
        return(
            <div className="container">
            <div className="row">
                <div className="col-12 col-md-5 m-1">
                    <Card>
                        <CardImg width="100%" src={this.props.restaurant.image} alt={this.props.restaurant.name}/>
                        <CardBody>
                            <CardTitle>{this.props.restaurant.name}</CardTitle>
                            <CardText>{this.props.restaurant.description}</CardText>
                        </CardBody>
                    </Card>
                </div>
    
                <div className="col-12 col-md-5 m-1">
                    {this.renderComments(this.props.restaurant)}
                </div>
                </div>
            </div>
        );
    }
        else{
            return(
                <div></div>
            );
        }
    }
    
}



export default RestaurantDetail;