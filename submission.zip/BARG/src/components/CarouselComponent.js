import React from "react";
import { Carousel } from "react-responsive-carousel";

export default () => (
  <Carousel autoPlay infiniteLoop showStatus={false} showIndicators={false} showArrows={false} showThumbs={false} interval={5000}>
    <div>
        <h1>Get to know your favorite Restaurants</h1>
    </div>
    <div>
        <h1>We provide the best analysis</h1>
    </div>
    <div>
        <h1>Plan your next food marathon now!</h1>
    </div>
   
  </Carousel>
);
