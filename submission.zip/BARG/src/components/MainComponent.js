
import React, { Component } from 'react';

import Home from './HomeComponent';
import Restaurants from './RestaurantsComponent';
import Contact from './ContactComponent';
import RestaurantDetail from './RestaurantdetailComponent';
import About from './AboutComponent';
import Header from './HeaderComponent';
import Footer from './FooterComponent';
import Visualization from './VisualizationComponent';

import { Switch, Route, Redirect, withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import { postComment, fetchRestaurants, fetchComments, fetchPromos } from '../redux/ActionCreators';
import { actions } from 'react-redux-form';
import { TransitionGroup, CSSTransition } from 'react-transition-group';

const mapStateToProps = state => {
    return {
      restaurants: state.restaurants,
      comments: state.comments,
      promotions: state.promotions,
      leaders: state.leaders
    }
}

const mapDispatchToProps = (dispatch) => ({
  postComment: (restaurantId, rating, author, comment) => dispatch(postComment(restaurantId, rating, author, comment)),
  fetchRestaurants: () => {dispatch(fetchRestaurants())},
  resetFeedbackForm: () => {dispatch(actions.reset('feedback'))},
  fetchComments: () => dispatch(fetchComments()),
  fetchPromos: () => dispatch(fetchPromos())
});

class Main extends Component {

  constructor(props){
    super(props);

    this.state = {
      selectedRestaurant: null
    };
  }

 componentDidMount() {
   this.props.fetchRestaurants();
   this.props.fetchComments();
   this.props.fetchPromos();
 } 
  

onRestaurantSelect(restaurantId){
  this.setState({ selectedRestaurant: restaurantId})
}
  render() {

    const HomePage = () => {
      return(
          <Home 
              restaurant={this.props.restaurants.restaurants.filter((restaurant) => restaurant.featured)[0]}
              restaurantsLoading={this.props.restaurants.isLoading}
              restaurantsErrMess={this.props.restaurants.errMess}
              promotion={this.props.promotions.promotions.filter((promo) => promo.featured)}
              promoLoading={this.props.promotions.isLoading}
              promoErrMess={this.props.promotions.errMess}              
              leader={this.props.leaders.filter((leader) => leader.featured)[0]}
          />
      );
    }
    const RestaurantWithId = ({match}) => {
      return(
          <RestaurantDetail restaurant={this.props.restaurants.restaurants.filter((restaurant) => restaurant.id === parseInt(match.params.restaurantId,10))[0]} 
              isLoading={this.props.restaurants.isLoading}
              errMess={this.props.restaurants.errMess}
              comments={this.props.comments.comments.filter((comment) => comment.restaurantId === parseInt(match.params.restaurantId,10))}
              commentsErrMess={this.props.comments.errMess}            
              postComment = {this.props.postComment}
            />
      );
    };
    
    return (
      <div className="App">
        <Header/>
        <TransitionGroup>
          <CSSTransition key={this.props.location.key} classNames="page" timeout={300}>
            <Switch>
              <Route path="/home" component={HomePage}/>
              <Route exact path="/restaurants" component={() => <Restaurants restaurants={this.props.restaurants} comments={this.props.comments} onClick={(restaurantId) => this.onRestaurantSelect(restaurantId)} selectedRestaurant={this.state.selectedRestaurant}/>} />
              <Route path='/Restaurants/:restaurantId' component={RestaurantWithId} />
              <Route exact path="/contactus" component={() => <Contact resetFeedbackForm={this.props.resetFeedbackForm} />} />
              <Route exact path="/aboutus" component={() => <About leaders={this.props.leaders}/>} />
              <Route exact path="/visualization" component={() => <Visualization/>} />
              <Redirect to="/home" />
            </Switch>
          </CSSTransition>
        </TransitionGroup>
        <Footer />
      </div>
    );
  }
}

//Lifecycle methods
//Called when an instance of a component is being createc and inserted into the DOM
//contructor() , getDerivedStateFromProps(), render(), componentDidMount()

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(Main));
