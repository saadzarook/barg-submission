import React, { Component } from 'react';
import { Card, CardImg, CardText, CardBody,
    CardTitle,  Breadcrumb, BreadcrumbItem} from 'reactstrap';
import { Link } from 'react-router-dom';
import { Button, Modal, ModalHeader, ModalBody, Label, Col, Row } from 'reactstrap';
import { Control, LocalForm, Errors } from 'react-redux-form';
import { Loading } from './LoadingComponent';  
import { baseUrl } from '../shared/baseUrl';
import { FadeTransform, Fade, Stagger} from 'react-animation-components';

const maxLength = (len) => (val) => !(val) || (val.length <= len);
const minLength = (len) => (val) => val && (val.length >= len);

class CommentForm extends Component{

    constructor(props) {
        super(props);

        this.state = {
            isModalOpen: false
        };
        this.toggleModal = this.toggleModal.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);


    }

    handleSubmit(values) {
        this.toggleModal();
        this.props.postComment(this.props.restaurantId, values.rating, values.author, values.comment)
    }


    toggleModal() {
        this.setState({
          isModalOpen: !this.state.isModalOpen
        });
      }

    render(){
        return(
            <>
            <div className="container">
            <Modal isOpen={this.state.isModalOpen} toggle={this.toggleModal}>
                    <ModalHeader toggle={this.toggleModal}>Submit Comment</ModalHeader>
                    <ModalBody>
                    <LocalForm onSubmit={(values) => this.handleSubmit(values)}>
                            <Row className="form-group">
                            <Col md={12}>
                            <Label htmlFor="rating">Rating</Label>
                                    <Control.select model=".rating" name="rating"
                                        className="form-control">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </Control.select>
                            </Col>
                            </Row>
                            <Row className="form-group">
                                <Col md={12}>
                                <Label htmlFor="author">Your Name</Label>
                                <Control.text model=".author" id="author" name="author"
                                        placeholder="Your Name"
                                        className="form-control"
                                        validators={{
                                            minLength: minLength(3), maxLength: maxLength(15)
                                        }}
                                        />
                                        <Errors
                                        className="text-danger"
                                        model=".author"
                                        show="touched"
                                        messages={{
                                            minLength: 'Must be greater than 2 characters',
                                            maxLength: 'Must be 15 characters or less'
                                        }}
                                     />
                                </Col>
                            </Row>
                            <Row className="form-group">
                                <Label htmlFor="comment" md={2}>Comment</Label>
                                <Col md={12}>
                                    <Control.textarea model=".comment" id="comment" name="comment"
                                        rows="6"
                                        className="form-control"
                                        />
                                </Col>
                            </Row>
                            <Button type="submit" value="submit" color="primary">Submit</Button>
                        </LocalForm>
                    </ModalBody>
            </Modal>
            </div>
            
            <Button outline onClick={this.toggleModal}><span className="fa fa-pencil fa-lg"></span> Submit Comment</Button>
        
        </>
                
        );

    }


}

    function RenderRestaurant({restaurant}) {
        if(restaurant != null){
            return(
                <FadeTransform in 
                transformProps = {{
                    exitTransform: 'scale(0.5) translateY(-50%)'
                }}>
                    <Card>
                        <CardImg top src={baseUrl + restaurant.image} alt={restaurant.name} />
                        <CardBody>
                            <CardTitle>{restaurant.name}</CardTitle>
                            <CardText>{restaurant.description}</CardText>
                        </CardBody>
                    </Card>
                </FadeTransform>
                
            );
        }else{
            return(
                <div></div>
            );
        }
        
    }

    function RenderComments({comments, postComment, restaurantId}) {
        if(comments != null){
            return(
                <div>
                      <h4>Comments</h4>
                      <Stagger in>
                      {comments.map((comment => {
        
                          return(
                            <Fade in>
                                <div key={comment.id}>
                                    <p>{comment.comment}</p>
                                    <p>-- {comment.author}, {new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'short', day: '2-digit'}).format(new Date(Date.parse(comment.date)))}</p>
                                </div>
                              </Fade>
                              
                          );
                      }))}
                      </Stagger>
                    <CommentForm restaurantId={restaurantId} postComment={postComment}/>
                  </div>
              );
        }
        else{
            return(
                <div></div>
            );
        }
      
    }

    const  RestaurantDetail = (props) => {
        if(props.isLoading) {
            return(
                <div className="container">
                    <div className="row">
                        <Loading />
                    </div>
                </div>
                
            );
        }
        else if(props.errMess){
            return(
                <div className="container">
                    <div className="row">
                        <h4>{props.errMess}</h4>
                    </div>
                </div>
                
            );
        }
        else if (props.restaurant != null){
            return (
                <div className="container">
                <div className="row">
                    <Breadcrumb>
                        <BreadcrumbItem><Link to="/restaurants">Restaurants</Link></BreadcrumbItem>
                        <BreadcrumbItem active>{props.restaurant.name}</BreadcrumbItem>
                    </Breadcrumb>
                    <div className="col-12">
                        <h3>{props.restaurant.name}</h3>
                        <hr />
                    </div>                
                </div>
                <div className="row">
                    <div className="col-12 col-md-5 m-1">
                        <RenderRestaurant restaurant={props.restaurant} />
                    </div>
                    <div className="col-12 col-md-5 m-1">
                        <RenderComments comments={props.comments} 
                        postComment={props.postComment}
                        restaurantId={props.restaurant.id}/>
                        
                    </div>
                </div>
                </div>
            );
            }
    }

export default RestaurantDetail;