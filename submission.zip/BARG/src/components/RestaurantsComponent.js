import React from 'react';
import { Card, CardImg, CardImgOverlay,
    CardTitle, Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { Link } from 'react-router-dom';
import { Loading } from './LoadingComponent';
import { baseUrl } from '../shared/baseUrl';


    function RenderRestaurantItem ({restaurant, onClick}) {
        return (
            <Card>
                <Link to={`/restaurants/${restaurant.id}`} >
                <CardImg width="100%" src={baseUrl + restaurant.image} alt={restaurant.name} />
                    <CardImgOverlay>
                        <CardTitle>{restaurant.name}</CardTitle>
                    </CardImgOverlay>
                </Link>
            </Card>
        );
    }

    const Restaurants = (props) => {

        //console.log(props.selectedRestaurant)
        const restaurants = props.restaurants.restaurants.map((restaurant) => {
            return (
                <div className="col-12 col-md-5 m-1"  key={restaurant.id}>
                    <RenderRestaurantItem restaurant={restaurant} onClick={props.onClick} />
                </div>
            );
        });

        if(props.restaurants.isLoading) {
            return(
                <div className="container">
                    <div className="row">
                        <Loading />
                    </div>
                </div>
                
            );
        }
        else if(props.restaurants.errMess){
            return(
                <div className="container">
                    <div className="row">
                        <h4>{props.restaurants.errMess}</h4>
                    </div>
                </div>
                
            );
        }
        else{
            return (
                <div className="container">
                    <div className="row">
                        <Breadcrumb>
                            <BreadcrumbItem><Link to="/home">Home</Link></BreadcrumbItem>
                            <BreadcrumbItem active>Restaurants</BreadcrumbItem>
                        </Breadcrumb>
                        <div className="col-12">
                            <h3>Restaurants</h3>
                            <hr />
                        </div>                
                    </div>
                    <div className="row">
                        {restaurants}
                    </div>
                </div>
            );
        }   
    }

export default Restaurants;