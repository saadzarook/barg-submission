import React, { Component } from 'react';
import { useEffect, useState } from 'react';
import { apiUrl } from '../shared/apiUrl';

const axios = require('axios').default;




class ReviewInput extends Component {
    constructor(props) {
      super(props);
      this.state = {
          value: '',
          sentiment : "Await...."
        };
      
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
      
    }
  

    handleChange(event) {    
        this.setState({value: event.target.value}); 
     }
    handleSubmit(event) {
            axios.post(apiUrl + 'api/',JSON.stringify(this.state.value), {  
              headers : {
                'content-type': 'application/json' ,
                'Access-Control-Allow-Origin': '*',
              }
              })
              .then((response) => {
                console.log(response.data);
                this.setState({ sentiment: response.data});
              }
              , (error) => {
                console.log(error);
              });
              

        
        
      event.preventDefault();
    }
  
    render() {
      return (
        <div className="container">
                    <div className="row">
                      <form onSubmit={this.handleSubmit}>
                        <label>
                            Review: 
                        <input type="text" value={this.state.value} onChange={this.handleChange} />        </label>
                        <input type="submit" value="Submit" />
                        <h2>Response:</h2>
                        <h3>{this.state.sentiment}</h3>
                    </form>
     
                    </div>
                </div>
        
        ); }
  }

  export default ReviewInput;