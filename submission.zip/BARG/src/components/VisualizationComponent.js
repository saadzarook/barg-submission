import React from 'react';
import "@progress/kendo-theme-material/dist/all.css";
import "hammerjs";
import Donut from './charts/donut';
import ReviewInput from './ReviewInputComponent';
import { useEffect, useState } from 'react';
import { apiUrl } from '../shared/apiUrl';

const axios = require('axios').default;
function Visualization(props) {
  
    const [getMessage, setGetMessage] = useState({})

  useEffect(()=>{
    axios.get(apiUrl + 'flask/hello').then(response => {
      console.log("SUCCESS", response)
      setGetMessage(response.message)
    }).catch(error => {
      console.log(error)
    })

  }, [])

 

  
    return(
        <div className="container">
            <div className="row align-items-start">
                <div className="col-12 col-md m-1">
                    <p>This is the Visualization</p>
                    <Donut />
                    <ReviewInput />
                </div>
            </div> 
        </div>
    );
}

export default Visualization;