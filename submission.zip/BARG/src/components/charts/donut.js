import {
    Chart,
    ChartTitle,
    ChartLegend,
    ChartSeries,
    ChartSeriesItem,
    ChartSeriesLabels,
    ChartTooltip
  } from "@progress/kendo-react-charts";
  import { COLORS } from "../../shared/colors";
  
  const renderTooltip = context => {
    const { category, value } = context.point || context;
    return (
      <div>
        {category}: {value}%
      </div>
    );
  };


  // Graph data
  const RestaurantRatings = [
    {
      status: "Excellent",
      value: 14,
      color: COLORS.excellent,
    },
    {
      status: "Good",
      value: 14,
      color: COLORS.good,
    },
    {
      status: "Average",
      value: 40,
      color: COLORS.average,
    },
    {
      status: "Bad",
      value: 32,
      color: COLORS.poor,
    },
  ];
  
  // Show category label for each item in the donut graph
  const labelContent = e => e.category;
  
  const Donut = props => {
    return (
      <Chart>
        <ChartTitle text="Restaurant Ratings" />
        <ChartLegend visible={false} />
        <ChartTooltip render={renderTooltip} />
        <ChartSeries>
          <ChartSeriesItem
            type="donut"
            data={RestaurantRatings}
            categoryField="status"
            field="value"
          >
            <ChartSeriesLabels
              color="#fff"
              background="none"
              content={labelContent}
            />
          </ChartSeriesItem>
        </ChartSeries>
      </Chart>
    );
  };
  
  export default Donut;
  