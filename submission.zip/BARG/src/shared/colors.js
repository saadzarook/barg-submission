export const COLORS = {
    excellent: "#059669",
    good: "#B91C1C",
    average: "#6366F1",
    poor: "#2563EB",
    worse: "#D97706",
  };
  