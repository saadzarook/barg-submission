export const LEADERS = [
    {
      id: 0,
      name: 'Ganidu',
      image: '/assets/images/avatar.png',
      designation: 'Developer',
      abbr: 'CEO',
      featured: false,
      description: "About you"    
    },
    {
      id: 1,
      name: 'Saad',
      image: '/assets/images/avatar.png',
      designation: 'Developer',
      abbr: 'CFO',
        featured: false,
        description: "About you"    
      },
    {
      id: 2,
      name: 'Gayath',
      image: '/assets/images/avatar.png',
      designation: 'Developer',
      abbr: 'CTO',
        featured: false,
        description: "About you"    
      },
    {
      id: 3,
      name: 'Yashini',
      image: '/assets/images/avatar.png',
      designation: 'Developer',
      abbr: 'EC',
      featured: false,
      description: "About you"    
    },
    {
      id: 4,
      name: 'Saranga',
      image: '/assets/images/avatar.png',
      designation: 'Developer',
      abbr: 'CTO',
        featured: false,
        description: "About you"    
      },
    {
      id: 5,
      name: 'Pasindu',
      image: '/assets/images/avatar.png',
      designation: 'Developer',
      abbr: 'EC',
      featured: false,
      description: "About you"    
    }
  ];