from flask import Flask, send_from_directory, request, redirect, url_for, flash, jsonify
from flask_restful import Api, Resource, reqparse
from flask_cors import CORS, cross_origin
from api.filterAPI import filterAPI
import re, string, random

import nltk
nltk.data.path.append('./nltk_data/')
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import wordnet as wn
from nltk.corpus import stopwords
from nltk.tag import pos_tag
from nltk.tokenize import word_tokenize
import pickle as p
import json
#import sys
#print(sys.path)

app = Flask(__name__)
CORS(app, support_credentials=True)
api = Api(app)

wn.ensure_loaded() 

stop_words = stopwords.words('english')
new_stopwords = ["food", "drink", "experience", "price", "order", "taste", "service", "location",
                    "place", "restaurant", "pizza", "burger", "work", "buy", "staff", "ice", "coffee", "piece", "...", ""]
stop_words.extend(new_stopwords)
stop_words = set(stop_words)
exclude_words = set(("not", "wouldn't", "don't", "don", "didn't", "doesn't", "wasn't", "won't", "won", "wouldn", "no", "isn't"))
new_stop_words = stop_words - exclude_words
stop_words = list(new_stop_words)
lemmatizer = WordNetLemmatizer()





#CORS(app) #comment this on deployment


@app.route("/", methods=['POST','GET'])
@cross_origin(supports_credentials=True)
def serve():
    return "<h1>Welcome to our BARG server !!</h1>"

api.add_resource(filterAPI, '/flask/hello')


@app.route('/api/', methods=['POST','GET'])
@cross_origin(supports_credentials=True)
def makecalc():
    data = request.get_json()
    print(data)
    modelfile = 'nltk_sentiment.pickle'
    model = p.load(open(modelfile, 'rb'))

    custom_tokens = remove_noise(word_tokenize(data), stop_words)
    prediction = model.classify(dict([token, True] for token in custom_tokens))

    return prediction

def remove_noise(review_tokens, stop_words = ()):

    cleaned_tokens = []

    for token, tag in pos_tag(review_tokens):
        token = re.sub('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+#]|[!*\(\),]|'\
                       '(?:%[0-9a-fA-F][0-9a-fA-F]))+','', token)
        token = re.sub("(@[A-Za-z0-9_]+)","", token)

        if tag.startswith("NN"):
            pos = 'n'
        elif tag.startswith('VB'):
            pos = 'v'
        else:
            pos = 'a'

        token = lemmatizer.lemmatize(token, pos)

        if len(token) > 0 and token not in string.punctuation and token.lower() not in stop_words:
            cleaned_tokens.append(token.lower())
    return cleaned_tokens

	
